//
//  main.c
//  Project2
//
//  Created by kevin fremgen on 12/1/20.
//


/*****************************
 This program implements the deadline monotonic algoirthm.
 
 *****************************/

#include <stdio.h>

int initT (int taskNum, int (*taskInfo)[3]){
    int i;
    // Hold the result of taskInfo for taskNum
    int result = 0;
    
    // Loop through taskNum to 0
    for (i=taskNum; i>=0; i--){
        // Add the computation time to result
        result += taskInfo[i][0];
    }
    // return it
    return result;
}

int interfere(int taskNum, int (*taskInfo)[3], int t){
    int i;
    int result = 0;
    
    if ( taskNum == 0 )
        return result;
    
    for(i=taskNum-1; i>=0; i--){
        int T = taskInfo[i][2];
        int C = taskInfo[i][0];
        int tmp = t/T;
        
        // ceiling
        if ( t%T > 0)
            tmp += 1;
        
        result += tmp * C;
    }
    return result;
}

int newT (int taskNum, int (*taskInfo)[3], int t){
    return interfere(taskNum, taskInfo, t) + taskInfo[taskNum][0];
}

int IsResponstime (int computation, int taskNum, int t, int (*taskInfo)[3]){
    if ( computation+interfere(taskNum, taskInfo, t) == t)
        return 1;
    return 0;
}


// Obtain 3 values that will be inserted to taskInfo with sorting
void insertSort(int taskNum, int (*taskInfo)[3], int computation, int deadline, int period){
    
    int i;
    
    // first element
    if (taskNum == 0){
        // Set the computation,deadline, and period to element 0 in taskInfo
        taskInfo[0][0] = computation;
        taskInfo[0][1] = deadline;
        taskInfo[0][2] = period;
    }
    
    // compare and insert
    else{
        // Loop through a range of taskNum to 0
        for (i=taskNum; i>0; i--){
            // Check if the current deadline for taskNum is less than the deadline for  taskNum -1
            if (deadline < taskInfo[i-1][1]){
                // If it is set the taskInfo at element taskNum to the taskInfo at element taskNum -1
                taskInfo[i][0] = taskInfo[i-1][0];
                taskInfo[i][1] = taskInfo[i-1][1];
                taskInfo[i][2] = taskInfo[i-1][2];
            }
            
            else
                break;
        }
        
        // Set the element at i in taskInfo to the computation,deadline, and period passed in
        taskInfo[i][0] = computation;
        taskInfo[i][1] = deadline;
        taskInfo[i][2] = period;
    }
}

int main(void) {
    
    // File object stream
    FILE *inputFile;
    // Hold the total number of task
    int totalTask;
    // Hold the task num
    int taskNum;
    
    // Task computation time, deadline, period
    int tmp_c,tmp_d,tmp_p;
    
    
    // Associates a new filename with the given open stream and at the same time closes the old file in the stream.
    // If the file was re-opened successfully, the function returns a pointer to an object identifying the stream or else, null pointer is returned.
    //"/Users/kevinfremgen/Desktop/CSC716/Project2/Project2/input.txt"
    inputFile =  fopen("/Users/kevinfremgen/Desktop/CSC716/Project2/Project2/input.txt", "r");
    
    printf("\n======== Task =========\n");
    // Read the first line of text, this hold the number of task
    fscanf(inputFile,"%d", &totalTask);
    printf("\nNumber of task: %d\n", totalTask);
    
    //Create a two d array of totalTask rows by 3 columns
    int taskInfo[totalTask][3];
    
    // Loop over the file lines
    // Get task information as (computation time, deadline, period) with priority according to DEADlINE using InsertSort
    for(taskNum = 0; taskNum < totalTask; taskNum++) {
        printf("\n----- Task %d info -----\n",taskNum);
        fscanf(inputFile,"%d", &tmp_c);
        printf("Computation time: %d\n", tmp_c);
        fscanf(inputFile,"%d", &tmp_d);
        printf("Deadline: %d\n", tmp_d);
        fscanf(inputFile, "%d", &tmp_p);
        printf("Period: %d\n", tmp_p);
        // Sort the task info
        insertSort(taskNum, taskInfo, tmp_c, tmp_d, tmp_p);
    }
    
    // Close the file object stream
    fclose(inputFile);
    
    printf("\nNote : This program  presents the result in order with Deadline\n");
    printf("\n========== Task Table ==========\n\n");
    //Print the order fo the task table
    for (taskNum=0; taskNum < totalTask; taskNum++){
        printf("Task %d = (%d, %d, %d)\n",taskNum+1, taskInfo[taskNum][0], taskInfo[taskNum][1],taskInfo[taskNum][2]);
    }
    
    printf("\n========== Task Number : Response time , Schedulable =========\n\n");
    
    // Each Task
    for(taskNum = 0; taskNum < totalTask; taskNum++){
        int t = initT(taskNum, taskInfo); // compoutation time for task
        int D = taskInfo[taskNum][1]; // deadline for task
        char s;
        
        // calculate response time with t
        while (!IsResponstime(taskInfo[taskNum][0], taskNum, t, taskInfo)){
            t = newT(taskNum, taskInfo, t);
            if ( t < 0 ){
                t = -1;
                break;
            }
        }
        
        // evaluate schedulability
        if ( t > D || t == -1)
            s = 'X';
        else
            s = 'O';
        
        // print response time & schedulable
        printf("Task %d : %d , %c\n", taskNum+1, t, s);
        
    }
    
    
    return 0;
}
